package com.sd.wedding2;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

    public class dbhandler extends SQLiteOpenHelper {

        // creating a constant variables for our database.
        // below variable is for our database name.
        private static final String DB_NAME = "inviteDB";

        // below int is our database version
        private static final int DB_VERSION = 1;

        // below variable is for our table name.
        private static final String TABLE_NAME = "GuestData";

        // below variable is for our id column.
        private static final String ID_COL = "id";

        // below variable is for our first, last and table number columns
        private static final String FIRST_NAME_COL = "FirstName";
        private static final String LAST_NAME_COL = "LastName";
        private static final String TABLE_NUMBER = "TableNumber";

        // below variable id for our day/evening guest column.
        private static final String DAY = "DayGuest";

        // below variable for our age range column.
        private final Integer AGE_RANGE_COL = 0;

        // below variable is for our overnight column.
        private static final String OVERNIGHT = "Overnight";

        private static final String STARTER_CHOICE_COL = "Starters";
        private static final String MAINS_CHOICE_COL = "Mains";
        private static final String DESSERT_CHOICE_COL = "Desserts";

        // creating a constructor for our database handler.
        public dbhandler(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        // below method is for creating a database by running a sqlite query
        @Override
        public void onCreate(SQLiteDatabase db) {
            // on below line we are creating
            // an sqlite query and we are
            // setting our column names
            // along with their data types.
            String query = "CREATE TABLE " + TABLE_NAME + " ("
                    + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + FIRST_NAME_COL + " TEXT,"
                    + LAST_NAME_COL + " TEXT,"
                    + TABLE_NUMBER + " INTEGER,"
                    + DAY + " BOOLEAN,"
                    + OVERNIGHT + "BOOLEAN,"
                    + STARTER_CHOICE_COL + "TEXT,"
                    + MAINS_CHOICE_COL + "TEXT,"
                    + DESSERT_CHOICE_COL + "TEXT"
                    + AGE_RANGE_COL + "TEXT)";

            // at last we are calling a exec sql
            // method to execute above sql query
            db.execSQL(query);
        }

        // this method is use to add new course to our sqlite database.
        public void addNewGuest(String FirstName, String LastName, String age) { //String age,Boolean Dayguest, Boolean Overnightstay, String Starterchoice, String Mainschoice, String Dessertchoice) {

            // on below line we are creating a variable for
            // our sqlite database and calling writable method
            // as we are writing data in our database.
            SQLiteDatabase db = this.getWritableDatabase();

            // on below line we are creating a
            // variable for content values.
            ContentValues values = new ContentValues();

            // on below line we are passing all values
            // along with its key and value pair.
            values.put(FIRST_NAME_COL, FirstName);
            values.put(LAST_NAME_COL, LastName);
            //values.put(TABLE_NUMBER, Table);
            values.put(String.valueOf(AGE_RANGE_COL), age);
            //values.put(DAY, Dayguest);
            //values.put(OVERNIGHT, Overnightstay);
            //values.put(STARTER_CHOICE_COL, Starterchoice);
            //values.put(MAINS_CHOICE_COL, Mainschoice);
            //values.put(DESSERT_CHOICE_COL, Dessertchoice);

            // after adding all values we are passing
            // content values to our table.
            db.insert(TABLE_NAME, null, values);

            // at last we are closing our
            // database after adding database.
            db.close();
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // this method is called to check if the table exists already.
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }





}
