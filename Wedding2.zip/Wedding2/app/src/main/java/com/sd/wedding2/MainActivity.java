package com.sd.wedding2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {


    private RadioGroup radioGroup;
    private RadioButton radioButton;

    // creating variables for our edittext, button and dbhandler
     AgeEdt;//TableEdt1, TableEdt2, TableEdt3,TableEdt4,TableEdt5,TableEdt6,TableEdt7,TableEdt8, AgeEdt, DayEdt, OvernightEdt, StartersEdt, MainsEdt, DessertsEdt;
    private dbhandler dbHandler;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initializing all our variables.
        EditText FirstNameEdt;
        FirstNameEdt = findViewById(R.id.editTextFirstName);
        EditText LastNameEdt;
        LastNameEdt = findViewById(R.id.editTextLastName);
        //TableEdt1 = findViewById(R.id.ageGroup);
        //EditText AgeEdt;
        //AgeEdt = findViewById(R.id.RadioGroup);
        //DayEdt = findViewById(R.id.DaySwitch);
        //OvernightEdt = findViewById(R.id.OvernightSwitch);
        //StartersEdt = findViewById(R.id.RPS), (R.id.PCT), (R.id.MS);
        //MainsEdt = findViewById(R.id.PT), (R.id.VW),(R.id.RPM);
        //DessertsEdt = findViewById(R.id.CB),(R.id.NYC);
        Button submitBtn = findViewById(R.id.SubmitBtn);

        // creating a new dbhandler class
        // and passing our context to it.
        dbHandler = new dbhandler(MainActivity.this) {
            @Override
            public void addNewGuest(String FirstName, String LastName, String age) {

            }
        };

        // below line is to add on click listener for our add course button.
        submitBtn.setOnClickListener(v -> {

            // below line is to get data from all edit text fields.
            String FirstName = FirstNameEdt.getText().toString();
            String LastName = LastNameEdt.getText().toString();
            //String age = RadioGroup.generateViewId();
            //
            RadioGroup rg = findViewById(R.id.RadioGroup);
            int selectedId = rg.getCheckedRadioButtonId();
            String age = getAgeString(selectedId);
            //String age = AgeEdt.getText().toString();
            //Boolean DayGuest = DayEdt.getText().toString();
            //Boolean Overnight = OvernightEdt.getText().toString();
            //String Starters = StartersEdt.getText().toString();
            //String Mains = MainsEdt.getText().toString();
            //String Desserts = DessertsEdt.getText().toString();

            // validating if the text fields are empty or not.

            if (FirstName.isEmpty() && LastName.isEmpty()) { //&& DayGuest.isEmpty() && Overnight.isEmpty() && Starters.isEmpty() && Mains.isEmpty() && Desserts.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                return;
            }

            // on below line we are calling a method to add new
            // course to sqlite data and pass all our values to it.
            dbHandler.addNewGuest(FirstName, LastName, String.valueOf(age));// Table, DayGuest, Overnight, Starters, Mains, Desserts);

            // after adding the data we are displaying a toast message.
            Toast.makeText(MainActivity.this, "New Guest has been added", Toast.LENGTH_SHORT).show();
            FirstNameEdt.setText("");
            LastNameEdt.setText("");
            //AgeEdt.setText("");
            //TableEdt.setText("");
            //DayEdt.setText("");
            //OvernightEdt.setText("");
            //StartersEdt.setText("");
            //MainsEdt.setText("");
            //DessertsEdt.setText("");
        });
    }

    private String getAgeString(int rbId) {
        String ageString = "";
        switch (rbId){
            case R.id.three2ten:
                ageString = "3-10 years";
                break;

            case R.id.under3:
                ageString = "Under 3";
                break;

            case R.id.over18:
                ageString = "Over 18";
                break;

            case R.id.eleven2seventeen:
                ageString = "11 - 17 years";
                break;
        }
        return ageString;
    };
}

